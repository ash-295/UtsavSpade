# UtsavSpade
This is a live streaming platform for Spade EMS
